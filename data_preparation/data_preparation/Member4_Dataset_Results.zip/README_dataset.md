
# Corn Disease Segmentation Dataset

## Dataset Source
PlantSeg: https://huggingface.co/datasets/LFTTim/plantseg_disease_segmentation

## Dataset Details
Total image-mask pairs: 616

- Training: 427
- Validation: 67
- Testing: 122

## Dataset Structure
- train/images
- train/masks
- validation/images
- validation/masks
- test/images
- test/masks

## Preprocessing
1. Extracted Corn images and corresponding masks.
2. Preserved the original dataset splits.
3. Verified image-mask matching.
4. Verified image and mask dimensions.
5. Generated binary masks.
   - 0: Background
   - 255: Disease region

## Evaluation
Dice Score, Intersection over Union (IoU),
and Precision will be calculated using
predictions from the trained segmentation model.
